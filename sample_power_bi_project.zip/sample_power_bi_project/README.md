# Sample Power BI Project

This sample project contains demo sales data for creating a Power BI dashboard.

## Files Included

- sales_data.csv → Sample dataset
- dashboard_ideas.txt → Dashboard suggestions

## Suggested Visualizations

1. Sales by Region
2. Profit by Product
3. Monthly Sales Trend
4. KPI Cards:
   - Total Sales
   - Total Profit
   - Orders Count

## How to Use

1. Open Power BI Desktop
2. Click Home → Get Data → Text/CSV
3. Import sales_data.csv
4. Build visuals using the dataset

