# Sample Unity Project

This is a simple sample Unity project structure.

## Included
- Sample C# player movement script
- Basic scene placeholder
- Project structure

## How to Use
1. Extract the ZIP file
2. Open Unity Hub
3. Click "Open"
4. Select the extracted folder

## Unity Version
Recommended: Unity 2022 or newer
